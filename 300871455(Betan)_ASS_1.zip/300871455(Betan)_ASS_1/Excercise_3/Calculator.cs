﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace Excercise_3
{
  public  class Calculator : INotifyPropertyChanged
    {
        double val;
        private string celsius;
        private string fahrenheit;

        
        public string Fahrenheit
        {
            get
            { return fahrenheit; }
            set
            {
                if (fahrenheit != value)
                {
                    fahrenheit = value;
                    OnPropertyChanged("Fahrenheit");
                    OnPropertyChanged("Celsius");
                }
            }
        }
        public string Celsius
        {
            get {
                val =  0.55  * (Convert.ToInt32(fahrenheit) - 32);
                return celsius = val.ToString();


            }
            set
            {
                if (celsius != value)
                {
                    celsius = value;
                    OnPropertyChanged("Celsius");
                }

            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string property)
        {
            if(PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
    }
}
