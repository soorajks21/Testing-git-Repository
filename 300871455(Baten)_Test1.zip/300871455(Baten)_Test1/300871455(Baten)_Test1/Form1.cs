﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _300871455_Baten__Test1
{
    public partial class Form1 : Form
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Desktop\ALICO\Ivascu\MidTestPrep - Copy\MidPrep\SalesDB.mdf;Integrated Security=True" ;
        public Form1()
        {
            InitializeComponent();
        }

        private void addCustomer_Click(object sender, EventArgs e)
        {
            using (SqlConnection sqlConnection = new SqlConnection(connectionString))
            {

                sqlConnection.Open();
               
                SqlCommand sqlCmd = new SqlCommand("AddUser", sqlConnection);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@CustomerId", customerId.Text);
                sqlCmd.Parameters.AddWithValue("@NameStyle", fontStyle.Text);
                sqlCmd.Parameters.AddWithValue("@Title", title.Text);
                sqlCmd.Parameters.AddWithValue("@FirstName", FName.Text);
                sqlCmd.Parameters.AddWithValue("@LastName", LName.Text);
                sqlCmd.Parameters.AddWithValue("@CompanyName", CName.Text);
                sqlCmd.Parameters.AddWithValue("@SalesPerson", SPerson.Text);
                sqlCmd.Parameters.AddWithValue("@EmailAddress", EMail.Text);
                sqlCmd.Parameters.AddWithValue("@Phone", Phone.Text);
                sqlCmd.Parameters.AddWithValue("@Password", Password.Text);
                sqlCmd.Parameters.AddWithValue("MiddleName", MName.Text);
                sqlCmd.ExecuteNonQuery();

                AddAddress();
            }
        }

        void AddAddress()
        {
            using (SqlConnection sqlConnection = new SqlConnection(connectionString))
            {
                sqlConnection.Open();

                SqlCommand sqlCmd = new SqlCommand("AddAddress", sqlConnection);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@AddressId", customerId.Text);
                sqlCmd.Parameters.AddWithValue("@Addressline1",line1_txt.Text);
                sqlCmd.Parameters.AddWithValue("@Addressline2", line2_txt.Text);
                sqlCmd.Parameters.AddWithValue("@City", City.Text);
                sqlCmd.Parameters.AddWithValue("@StateProvince", State.Text);
                sqlCmd.Parameters.AddWithValue("@CountryRegion", Country.Text);
                sqlCmd.Parameters.AddWithValue("@PostalCode", Postal.Text);
                sqlCmd.ExecuteNonQuery();


            }
        }

        private void FCustomer_Click(object sender, EventArgs e)
        {

            using (SqlConnection sqlConnection = new SqlConnection(connectionString))
            {
                sqlConnection.Open();
                
                string query = "Select * from customer where CustomerId = '" + customerId.Text.Trim()+"' ";
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query, sqlConnection);
                DataTable tbl = new DataTable();
                sqlDataAdapter.Fill(tbl);
               
                if (tbl.Rows.Count == 1)
                {
                    foreach (DataRow dr in tbl.Rows)
                    {
                        listBox1.Items.Add( dr["FirstName"].ToString()+"/r/n" + dr["LastName"].ToString()+ "/r/n"+ dr["MiddleName"].ToString()+"/r/n"+
                                                dr["CompanyName"].ToString()+"/r/n"+dr["Title"].ToString() );
                    }

                }


            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection sqlConnection = new SqlConnection(connectionString))
            {
                sqlConnection.Open();
                SqlCommand deleteCommand = sqlConnection.CreateCommand();
               deleteCommand.CommandText  = "Delete from customer where CustomerId = @CustomerId ";
                deleteCommand.Parameters.AddWithValue("@CustomerId", customerId.Text);
                deleteCommand.ExecuteNonQuery();


            }


            }

        private void button2_Click(object sender, EventArgs e)
        {
            using (SqlConnection sqlConnection = new SqlConnection(connectionString))
            {
                sqlConnection.Open();
                string query = "Select Customer.FirstName,Customer.LastName,Customer.CompanyName, Address.City,Address.Country " +
                                "From Customer INNER JOIN Address ON Customer.CustomerId= Address.AddressId where Address.Country=  '" + Country.Text.Trim() + "' ORDER BY =  '" + CName.Text.Trim() + "' ";
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query, sqlConnection);
                DataTable tbl = new DataTable();
                sqlDataAdapter.Fill(tbl);

                if (tbl.Rows.Count == 1)
                {
                    foreach (DataRow dr in tbl.Rows)
                    {
                        listBox1.Items.Add(dr["FirstName"].ToString() + "/r/n" + dr["LastName"].ToString() + "/r/n" + dr["MiddleName"].ToString() + "/r/n" +
                                               dr["CompanyName"].ToString() + "/r/n" + dr["Title"].ToString());
                    }

                }

            }

            }

        private void button3_Click(object sender, EventArgs e)
        {

            using (SqlConnection sqlConnection = new SqlConnection(connectionString))
            {
                sqlConnection.Open();
                string query = "Select Customer.FirstName,Customer.LastName,Customer.CompanyName, Address.City,Address.Country " +
                                "From Customer INNER JOIN Address ON Customer.CustomerId= Address.AddressId  ORDER BY =  '" + FName.Text.Trim() + "' ";
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query, sqlConnection);
                DataTable tbl = new DataTable();
                sqlDataAdapter.Fill(tbl);

                if (tbl.Rows.Count == 1)
                {
                    foreach (DataRow dr in tbl.Rows)
                    {
                        listBox1.Items.Add(dr["FirstName"].ToString() + "/r/n" + dr["LastName"].ToString() + "/r/n" + dr["MiddleName"].ToString() + "/r/n" +
                                               dr["CompanyName"].ToString() + "/r/n" + dr["Title"].ToString());
                    }

                }

            }


        }
    }
}