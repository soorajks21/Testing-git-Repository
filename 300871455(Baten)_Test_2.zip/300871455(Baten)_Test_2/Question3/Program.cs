﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question3
{
    class Program
    {
        static void Main(string[] args)
        {
            int ch,c = 0;
            List<int> dice = new List<int>();
            do
            {
                Console.WriteLine("1.Roll Dice" + " " + "2. Display" + " " + "3.Exit");
                ch = Convert.ToInt32(Console.ReadLine());

                switch (ch)
                {
                    case 1:
                        Random random = new Random();
                        Console.WriteLine("Rolling");
                        for (int i = 0; i <= 100000000; i++)
                        {
                            dice.Add(random.Next(1, 7));

                        }





                        break;

                    case 2:
                        Console.WriteLine(" values generated in Dice");


                        var e = dice.Select(a => a == 1);
                      foreach(var val in e)
                        {
                            if(val == true)
                            c++;
                        }
                        Console.WriteLine("Frequency of one: "+c);


                        c = 0;
                        var two = dice.Select(a => a == 2);
                        foreach (var val in two)
                        {
                            if (val == true)
                                c++;
                        }
                        Console.WriteLine("Frequency of two: " + c);



                        c = 0;
                        var three = dice.Select(a => a == 3);
                        foreach (var val in three)
                        {
                            if (val == true)
                                c++;
                        }
                        Console.WriteLine("Frequency of three: " + c);



                        c = 0;
                        var four = dice.Select(a => a == 4);
                        foreach (var val in four)
                        {
                            if (val == true)
                                c++;
                        }
                        Console.WriteLine("Frequency of four: " + c);


                        c = 0;
                        var five = dice.Select(a => a == 5);
                        foreach (var val in five)
                        {
                            if (val == true)
                                c++;
                        }
                        Console.WriteLine("Frequency of five: " + c);


                        c = 0;
                        var six = dice.Select(a => a == 6);
                        foreach (var val in six)
                        {
                            if (val == true)
                                c++;
                        }
                        Console.WriteLine("Frequency of six: " + c);


                        break;

                   

                }
            } while (ch != 3);
       
            }
    }
}
