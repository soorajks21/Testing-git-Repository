﻿namespace Question4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.numberOfDice = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.sequence = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Synchronous = new System.Windows.Forms.RadioButton();
            this.Asynchronous = new System.Windows.Forms.RadioButton();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(57, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Number of dice";
            // 
            // numberOfDice
            // 
            this.numberOfDice.FormattingEnabled = true;
            this.numberOfDice.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.numberOfDice.Location = new System.Drawing.Point(213, 26);
            this.numberOfDice.Name = "numberOfDice";
            this.numberOfDice.Size = new System.Drawing.Size(121, 24);
            this.numberOfDice.TabIndex = 1;
            this.numberOfDice.SelectedIndexChanged += new System.EventHandler(this.numberOfDice_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(60, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Size of sequence";
            // 
            // sequence
            // 
            this.sequence.FormattingEnabled = true;
            this.sequence.Items.AddRange(new object[] {
            "1000000",
            "2000000",
            "4000000",
            "8000000",
            "1600000"});
            this.sequence.Location = new System.Drawing.Point(213, 107);
            this.sequence.Name = "sequence";
            this.sequence.Size = new System.Drawing.Size(121, 24);
            this.sequence.TabIndex = 3;
            this.sequence.SelectedIndexChanged += new System.EventHandler(this.sequence_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(76, 384);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 17);
            this.label4.TabIndex = 7;
            this.label4.Text = "Control";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(213, 411);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "Start";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(213, 467);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 9;
            this.button2.Text = "Cancel";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Synchronous);
            this.groupBox1.Controls.Add(this.Asynchronous);
            this.groupBox1.Location = new System.Drawing.Point(63, 230);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 100);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "ThreadControl";
           
            // 
            // Synchronous
            // 
            this.Synchronous.AutoSize = true;
            this.Synchronous.Location = new System.Drawing.Point(58, 73);
            this.Synchronous.Name = "Synchronous";
            this.Synchronous.Size = new System.Drawing.Size(112, 21);
            this.Synchronous.TabIndex = 1;
            this.Synchronous.TabStop = true;
            this.Synchronous.Text = "Synchronous";
            this.Synchronous.UseVisualStyleBackColor = true;
            // 
            // Asynchronous
            // 
            this.Asynchronous.AutoSize = true;
            this.Asynchronous.Location = new System.Drawing.Point(58, 35);
            this.Asynchronous.Name = "Asynchronous";
            this.Asynchronous.Size = new System.Drawing.Size(119, 21);
            this.Asynchronous.TabIndex = 0;
            this.Asynchronous.TabStop = true;
            this.Asynchronous.Text = "Asynchronous";
            this.Asynchronous.UseVisualStyleBackColor = true;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(79, 538);
            this.progressBar1.Maximum = 8;
            this.progressBar1.Minimum = 1;
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(100, 23);
            this.progressBar1.TabIndex = 11;
            this.progressBar1.Value = 1;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 573);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.sequence);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.numberOfDice);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox numberOfDice;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox sequence;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton Synchronous;
        private System.Windows.Forms.RadioButton Asynchronous;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Timer timer1;
    }
}

