﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Question4
{
    public partial class Form1 : Form
    {
        System.Windows.Forms.Timer timer = new Timer();
        string strchecked;
        string selectedVal;
        public Form1()
        {
            InitializeComponent();
        }


       

        int numberofdice = 0, seq = 0;

        private void numberOfDice_SelectedIndexChanged(object sender, EventArgs e)
        {
            numberofdice = Convert.ToInt32( numberOfDice.SelectedValue);

        }

       

        private void sequence_SelectedIndexChanged(object sender, EventArgs e)
        {
            seq =Convert.ToInt32( sequence.SelectedValue);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        //private void groupBox1_Enter(object sender, EventArgs e)
        //{
        //    GroupBox g = sender as GroupBox;
        //    var a = from RadioButton r in g.Controls where r.Checked == true select r.Name;
        //   foreach( var val in a)
        //    {
        //        strchecked = val;
        //    }
        //}

        private void button1_Click(object sender, EventArgs e)
        {
         
            Random random = new Random();

            if(Synchronous.Checked)

            { 
                for (int i = 1; i <= numberofdice; i++)
                {

                    for (int j = 1; j <= seq; j++)
                    {
                        random.Next(1, 7);

                    }

                    progressBar1.Value = i;

                }

            }

            if(Asynchronous.Checked)
            {
                for (int i = 1; i <= numberofdice; i++)
                {

                    for (int j = 1; j <= seq; j++)
                    {
                        random.Next(1, 7);

                    }

                    progressBar1.Value = i;

                }

            }
        }

    }
}
