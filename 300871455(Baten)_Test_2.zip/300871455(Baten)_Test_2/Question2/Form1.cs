﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Question2
{
    public partial class Form1 : Form
    {
        SortedDictionary<string, int> sort = new SortedDictionary<string, int>();

            
        public Form1()
        {
            InitializeComponent();
            sort.Add("blue", 5);
            sort.Add("black", 2);
            sort.Add("green", 9);
            sort.Add("yellow", 4);
            sort.Add("white", 1);
            sort.Add("pink", 3);
            sort.Add("gold", 6);
            sort.Add("cyan", 7);
            sort.Add("red", 8);
            sort.Add("gray", 10);
           foreach(KeyValuePair<string, int> p in sort)
            {
                comboBox1.Items.Add(p.Key);
            }

        }
       
   

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

           
            
                
            switch (comboBox1.SelectedItem.ToString())
            {
                case "red": this.BackColor = System.Drawing.Color.Red;
                            break;
                case "blue":
                    this.BackColor = System.Drawing.Color.Blue;
                            break;
                case "green":
                    this.BackColor = System.Drawing.Color.Green;
                             break;

                case "yellow":
                    this.BackColor = System.Drawing.Color.Yellow;
                    break;

                case "pink":
                    this.BackColor = System.Drawing.Color.Pink;
                    break;


                case "gold":
                    this.BackColor = System.Drawing.Color.Gold;
                    break;


                case "white":
                    this.BackColor = System.Drawing.Color.White;
                    break;

                case "cyan":
                    this.BackColor = System.Drawing.Color.Cyan;
                    break;

                case "gray":
                    this.BackColor = System.Drawing.Color.Gray;
                    break;

                case "black":
                    this.BackColor = System.Drawing.Color.Black;
                    break;


            }
            
        }

       
    }
}
