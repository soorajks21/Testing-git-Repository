﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question1
{
    class Program
    {
        static void Main(string[] args)
        {


            int ch;
            string name;

            LinkedList<string> data = new LinkedList<string>();
            do
            {
                Console.WriteLine("1.Enter Deatils" + " " + "2. Display" + " " + "3. Search" + " " + "4.Exit");
                ch = Convert.ToInt32(Console.ReadLine());

                switch (ch)
                {
                    case 1:
                        Console.WriteLine("Enter Fname");
                        name = Console.ReadLine().ToLower();

                        if (data.Contains(name))
                        {
                            Console.WriteLine("Name already exists");
                        }
                        else
                        {
                            data.AddLast(name);

                        }
                        break;

                    case 2:
                        if (data != null)
                        {
                            foreach (var d in data)
                            {
                                Console.WriteLine(d);
                            }
                        }
                        else
                        {
                            Console.WriteLine("NO VALUES");
                        }
                        break;

                    case 3:
                        Console.WriteLine("Enter name to search");
                        name = Console.ReadLine().ToLower();
                        if (data.Contains(name))
                        {
                            Console.WriteLine("Name present in the list");
                        }
                        else
                        {
                            Console.WriteLine("Not found");
                        }

                        break;

                }


            } while (ch != 4);




        }
    }
}
