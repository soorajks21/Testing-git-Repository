﻿namespace _300871455_Baten__Test1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fontStyle = new System.Windows.Forms.TextBox();
            this.FName = new System.Windows.Forms.TextBox();
            this.title = new System.Windows.Forms.TextBox();
            this.MName = new System.Windows.Forms.TextBox();
            this.LName = new System.Windows.Forms.TextBox();
            this.CName = new System.Windows.Forms.TextBox();
            this.SPerson = new System.Windows.Forms.TextBox();
            this.EMail = new System.Windows.Forms.TextBox();
            this.Phone = new System.Windows.Forms.TextBox();
            this.Password = new System.Windows.Forms.TextBox();
            this.addCustomer = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.FCustomer = new System.Windows.Forms.Button();
            this.line1_txt = new System.Windows.Forms.TextBox();
            this.Postal = new System.Windows.Forms.TextBox();
            this.Country = new System.Windows.Forms.TextBox();
            this.State = new System.Windows.Forms.TextBox();
            this.City = new System.Windows.Forms.TextBox();
            this.line2_txt = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.customerId = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // fontStyle
            // 
            this.fontStyle.Location = new System.Drawing.Point(192, 88);
            this.fontStyle.Name = "fontStyle";
            this.fontStyle.Size = new System.Drawing.Size(100, 22);
            this.fontStyle.TabIndex = 0;
            // 
            // FName
            // 
            this.FName.Location = new System.Drawing.Point(192, 194);
            this.FName.Name = "FName";
            this.FName.Size = new System.Drawing.Size(100, 22);
            this.FName.TabIndex = 1;
            // 
            // title
            // 
            this.title.Location = new System.Drawing.Point(192, 139);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(100, 22);
            this.title.TabIndex = 2;
            // 
            // MName
            // 
            this.MName.Location = new System.Drawing.Point(192, 240);
            this.MName.Name = "MName";
            this.MName.Size = new System.Drawing.Size(100, 22);
            this.MName.TabIndex = 3;
            // 
            // LName
            // 
            this.LName.Location = new System.Drawing.Point(192, 285);
            this.LName.Name = "LName";
            this.LName.Size = new System.Drawing.Size(100, 22);
            this.LName.TabIndex = 4;
            // 
            // CName
            // 
            this.CName.Location = new System.Drawing.Point(192, 339);
            this.CName.Name = "CName";
            this.CName.Size = new System.Drawing.Size(100, 22);
            this.CName.TabIndex = 5;
            // 
            // SPerson
            // 
            this.SPerson.Location = new System.Drawing.Point(192, 386);
            this.SPerson.Name = "SPerson";
            this.SPerson.Size = new System.Drawing.Size(100, 22);
            this.SPerson.TabIndex = 6;
            // 
            // EMail
            // 
            this.EMail.Location = new System.Drawing.Point(192, 442);
            this.EMail.Name = "EMail";
            this.EMail.Size = new System.Drawing.Size(100, 22);
            this.EMail.TabIndex = 7;
            // 
            // Phone
            // 
            this.Phone.Location = new System.Drawing.Point(192, 496);
            this.Phone.Name = "Phone";
            this.Phone.Size = new System.Drawing.Size(100, 22);
            this.Phone.TabIndex = 8;
            // 
            // Password
            // 
            this.Password.Location = new System.Drawing.Point(192, 551);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(100, 22);
            this.Password.TabIndex = 9;
            // 
            // addCustomer
            // 
            this.addCustomer.Location = new System.Drawing.Point(337, 409);
            this.addCustomer.Name = "addCustomer";
            this.addCustomer.Size = new System.Drawing.Size(136, 23);
            this.addCustomer.TabIndex = 10;
            this.addCustomer.Text = "Add Customer";
            this.addCustomer.UseVisualStyleBackColor = true;
            this.addCustomer.Click += new System.EventHandler(this.addCustomer_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(61, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 17);
            this.label1.TabIndex = 11;
            this.label1.Text = "Customer Id";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(61, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 17);
            this.label2.TabIndex = 12;
            this.label2.Text = "Name Style";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(61, 147);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 17);
            this.label3.TabIndex = 13;
            this.label3.Text = "Title";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(61, 199);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 17);
            this.label4.TabIndex = 14;
            this.label4.Text = "FirstName";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(61, 245);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 17);
            this.label5.TabIndex = 15;
            this.label5.Text = "Middle Name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(61, 290);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 17);
            this.label6.TabIndex = 16;
            this.label6.Text = "Last Name";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(61, 344);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 17);
            this.label7.TabIndex = 17;
            this.label7.Text = "CompantName";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(61, 391);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 17);
            this.label8.TabIndex = 18;
            this.label8.Text = "Sales Person";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(61, 447);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(42, 17);
            this.label9.TabIndex = 19;
            this.label9.Text = "Email";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(61, 501);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(49, 17);
            this.label10.TabIndex = 20;
            this.label10.Text = "Phone";
            // 
            // FCustomer
            // 
            this.FCustomer.Location = new System.Drawing.Point(501, 409);
            this.FCustomer.Name = "FCustomer";
            this.FCustomer.Size = new System.Drawing.Size(189, 23);
            this.FCustomer.TabIndex = 22;
            this.FCustomer.Text = "Find Customer";
            this.FCustomer.UseVisualStyleBackColor = true;
            this.FCustomer.Click += new System.EventHandler(this.FCustomer_Click);
            // 
            // line1_txt
            // 
            this.line1_txt.Location = new System.Drawing.Point(530, 40);
            this.line1_txt.Name = "line1_txt";
            this.line1_txt.Size = new System.Drawing.Size(100, 22);
            this.line1_txt.TabIndex = 23;
            // 
            // Postal
            // 
            this.Postal.Location = new System.Drawing.Point(530, 324);
            this.Postal.Name = "Postal";
            this.Postal.Size = new System.Drawing.Size(100, 22);
            this.Postal.TabIndex = 24;
            // 
            // Country
            // 
            this.Country.Location = new System.Drawing.Point(530, 260);
            this.Country.Name = "Country";
            this.Country.Size = new System.Drawing.Size(100, 22);
            this.Country.TabIndex = 25;
            // 
            // State
            // 
            this.State.Location = new System.Drawing.Point(530, 196);
            this.State.Name = "State";
            this.State.Size = new System.Drawing.Size(100, 22);
            this.State.TabIndex = 26;
            // 
            // City
            // 
            this.City.Location = new System.Drawing.Point(530, 144);
            this.City.Name = "City";
            this.City.Size = new System.Drawing.Size(100, 22);
            this.City.TabIndex = 27;
            // 
            // line2_txt
            // 
            this.line2_txt.Location = new System.Drawing.Point(530, 93);
            this.line2_txt.Name = "line2_txt";
            this.line2_txt.Size = new System.Drawing.Size(100, 22);
            this.line2_txt.TabIndex = 28;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(396, 40);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(95, 17);
            this.label11.TabIndex = 29;
            this.label11.Text = "AddressLine1";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(396, 93);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(95, 17);
            this.label12.TabIndex = 30;
            this.label12.Text = "AddressLine2";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(396, 144);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(31, 17);
            this.label13.TabIndex = 31;
            this.label13.Text = "City";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(396, 201);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(41, 17);
            this.label14.TabIndex = 32;
            this.label14.Text = "State";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(396, 248);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(57, 17);
            this.label15.TabIndex = 33;
            this.label15.Text = "Country";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(396, 324);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(47, 17);
            this.label16.TabIndex = 34;
            this.label16.Text = "Postal";
            // 
            // customerId
            // 
            this.customerId.Location = new System.Drawing.Point(192, 41);
            this.customerId.Name = "customerId";
            this.customerId.Size = new System.Drawing.Size(100, 22);
            this.customerId.TabIndex = 35;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(61, 568);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(69, 17);
            this.label17.TabIndex = 36;
            this.label17.Text = "Password";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(337, 473);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(136, 23);
            this.button1.TabIndex = 37;
            this.button1.Text = "Delete";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(501, 529);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(189, 23);
            this.button2.TabIndex = 38;
            this.button2.Text = "By Company Name";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(501, 473);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(189, 23);
            this.button3.TabIndex = 39;
            this.button3.Text = "By FirstName";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // listBox1
            // 
            this.listBox1.Location = new System.Drawing.Point(747, 34);
            this.listBox1.Multiline = true;
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(376, 462);
            this.listBox1.TabIndex = 40;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(337, 529);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(136, 23);
            this.button4.TabIndex = 41;
            this.button4.Text = "Edit";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1178, 632);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.customerId);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.line2_txt);
            this.Controls.Add(this.City);
            this.Controls.Add(this.State);
            this.Controls.Add(this.Country);
            this.Controls.Add(this.Postal);
            this.Controls.Add(this.line1_txt);
            this.Controls.Add(this.FCustomer);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.addCustomer);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.Phone);
            this.Controls.Add(this.EMail);
            this.Controls.Add(this.SPerson);
            this.Controls.Add(this.CName);
            this.Controls.Add(this.LName);
            this.Controls.Add(this.MName);
            this.Controls.Add(this.title);
            this.Controls.Add(this.FName);
            this.Controls.Add(this.fontStyle);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox fontStyle;
        private System.Windows.Forms.TextBox FName;
        private System.Windows.Forms.TextBox title;
        private System.Windows.Forms.TextBox MName;
        private System.Windows.Forms.TextBox LName;
        private System.Windows.Forms.TextBox CName;
        private System.Windows.Forms.TextBox SPerson;
        private System.Windows.Forms.TextBox EMail;
        private System.Windows.Forms.TextBox Phone;
        private System.Windows.Forms.TextBox Password;
        private System.Windows.Forms.Button addCustomer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button FCustomer;
        private System.Windows.Forms.TextBox line1_txt;
        private System.Windows.Forms.TextBox Postal;
        private System.Windows.Forms.TextBox Country;
        private System.Windows.Forms.TextBox State;
        private System.Windows.Forms.TextBox City;
        private System.Windows.Forms.TextBox line2_txt;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox customerId;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox listBox1;
        private System.Windows.Forms.Button button4;
    }
}

